data.raw["map-settings"]["map-settings"].enemy_expansion.min_base_spacing = 6
data.raw["map-settings"]["map-settings"].enemy_expansion.max_expansion_distance = 10

data.raw["map-settings"]["map-settings"].enemy_expansion.min_expansion_cooldown = 10 * 4 * 3600
data.raw["map-settings"]["map-settings"].enemy_expansion.max_expansion_cooldown = 10 * 4 * 3600

data.raw["unit-spawner"]["biter-spawner"].max_count_of_owned_units = 15
data.raw["unit-spawner"]["biter-spawner"].max_friends_around_to_spawn = 10
data.raw["unit-spawner"]["biter-spawner"].spawning_cooldown = {180, 60}
data.raw["unit-spawner"]["biter-spawner"].spawning_radius = 15
data.raw["unit-spawner"]["biter-spawner"].call_for_help_radius = 80

data.raw["unit-spawner"]["spitter-spawner"].max_count_of_owned_units = 15
data.raw["unit-spawner"]["spitter-spawner"].max_friends_around_to_spawn = 10
data.raw["unit-spawner"]["spitter-spawner"].spawning_cooldown = {180, 60}
data.raw["unit-spawner"]["spitter-spawner"].spawning_radius = 15
data.raw["unit-spawner"]["spitter-spawner"].call_for_help_radius = 80

data.raw["ammo"]["flame-thrower-ammo"].stack_size = 1
data.raw["ammo"]["flame-thrower-ammo"].magazine_size = 200
data.raw["gun"]["rocket-launcher"].attack_parameters.range = 40
data.raw["gun"]["tank-cannon"].attack_parameters.range = 50

data.raw["turret"]["medium-worm-turret"].max_health = 1000
data.raw["turret"]["medium-worm-turret"].attack_parameters.damage_modifier = 10
data.raw["turret"]["big-worm-turret"].max_health = 10000
data.raw["turret"]["big-worm-turret"].attack_parameters.damage_modifier = 20

data.raw["ammo-turret"]["gun-turret"].attack_parameters.damage_modifier = 1.5
data.raw["electric-turret"]["laser-turret"].attack_parameters.damage_modifier = 3

data.raw["car"]["tank"].max_health = 5000

data.raw["projectile"]["rocket"].action = {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "explosion"
          },
          {
            type = "damage",
            damage = {amount = 2000, type = "explosion"}
          },
          {
            type = "create-entity",
            entity_name = "small-scorchmark",
            check_buildability = true
          }
        }
      }
  }
  
data.raw["projectile"]["explosive-rocket"].action = {
    type = "direct",
    action_delivery =
    {
      type = "instant",
      target_effects =
      {
        {
          type = "create-entity",
          entity_name = "explosion"
        },
        {
          type = "nested-result",
          action =
          {
            type = "area",
            perimeter = 6.5,
            action_delivery =
            {
              type = "instant",
              target_effects =
              {
                {
                  type = "damage",
                  damage = {amount = 1500, type = "explosion"}
                },
                {
                  type = "create-entity",
                  entity_name = "explosion"
                }
              }
            }
          },
        }
      }
    }
  }
  
data.raw["projectile"]["cannon-projectile"].action =
  {
    type = "direct",
    action_delivery =
    {
      type = "instant",
      target_effects =
      {
        {
          type = "damage",
          damage = { amount = 6000 , type = "physical"}
		  --damage = { amount = 3000 , type = "physical"}
        },
        {
          type = "damage",
          damage = { amount = 2000 , type = "explosion"}
		  --damage = { amount = 1000 , type = "explosion"}
        }
      }
    }
  }
  
data.raw["projectile"]["explosive-cannon-projectile"].action = 
{
  type = "direct",
  action_delivery =
  {
    type = "instant",
    target_effects =
    {
      {
        type = "damage",
        --damage = { amount = 1000, type = "physical"}
		damage = { amount = 2000, type = "physical"}
      }
    }
  }
}

data.raw["projectile"]["explosive-cannon-projectile"].final_action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "big-explosion",
            check_buildability = true
          },
          {
            type = "nested-result",
            action =
            {
              type = "area",
              perimeter = 4,
              action_delivery =
              {
                type = "instant",
                target_effects =
                {
                  {
                    type = "damage",
                    damage = {amount = 4000, type = "explosion"}
					--damage = {amount = 2000, type = "explosion"}
                  },
                  {
                    type = "create-entity",
                    entity_name = "explosion"
                  }
                }
              }
            }
          }
        }
      }
    }